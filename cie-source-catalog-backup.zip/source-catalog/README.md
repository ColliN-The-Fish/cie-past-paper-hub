# CIE Past Paper Hub active catalog backup

This backup contains only the website's 27 retained subjects and 25,254 files.
All 2,106 selected subject/year/session query snapshots, including empty results, are included.
Subject exclusions are defined in catalog-policy.json. Excluded subjects and their resources are omitted.
Source capture: 2026-10-10. Selection updated: 2026-10-11.
PDF, audio and video binaries are not included; download-links.json preserves the original download URLs.
